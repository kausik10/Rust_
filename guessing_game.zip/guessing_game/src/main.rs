use std::io;  //i/o library scope : preludge
//use std::io library provides useful feature like accepting user input
use rand::Rng; //Rng trait defines methods that random number generators implement, and this trait must be in the scope to use it
use std::cmp::Ordering;
//Ordering is a enum that has variants Less, Greater and equal 
fn main() {
	println!("Guess the number ");
	
	let secret_number = rand::thread_rng().gen_range(1..101);
	//println!("The secret number is: {}", secret_number);
	
	loop {
		println!("Please input a guess.");

	//creating variable
		let mut guess = String::new();  
	//a function that returns new instance of string::: creates a new instance of string
		
		io::stdin() //stdin func from io module. helps us to handle user input
		/* * If we hadn't used std::io at the beginning, we could still use stdin as 
		use std::io::stdin
		* */
			.read_line(&mut guess)
			/* * calls read_line methd on std io handle to get input from user.
				read_line takes whatever the user types into std input and append that into a string without overwriting it. So, we can pass string as an arguement
				
				references(&) are immutable like variables, so we need to write
				&mut guess instead of &guess to make it mutable.
			* */
			.expect("Failed to read line");
			
			
		let guess: u32 = match guess.trim().parse() {
			Ok(num) => num,
			Err(_) => continue,
		
		};
			
		println!("You guessed: {}", guess);
		//cmp method compares two values here it is comparing guess to secret number
		match guess.cmp(&secret_number){
			Ordering::Less => println!("Too small"),
			Ordering::Greater => println!("Too big"),
			Ordering::Equal => {
				println!("You win");
				break;
			}
		}
	}
}


/* * 
	Could have written the code as:
	io::stdin().read_line(&mut guess).expect("Failed to read line");
* */


//cargo doc --open 
